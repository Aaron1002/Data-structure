#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
    int n = 0;
    double UB = 0;
    double LB = 0;
    int rs = 0;
    int mid_element = 0;
    
    cout << "Enter the number of elements (n): ";
    cin >> n;
    cout << "Enter the lower bound (LB): ";
    cin >> LB;
    cout << "Enter the upper bound (UB): ";
    cin >> UB;
    
    while (UB < LB + 1){
        cout << "Follow the rule: UB>=LB+1" << endl;
        cout << "UB: ";
        cin >>  UB;
    }
    
    cout << "Enter the random seed (rs): ";
    cin >> rs; 
    
    double *arr = new double[n];
  
    srand(rs); // a fixed random number set 
    for (int i=0; i<n; i++){
        arr[i] = LB + static_cast<double>(rand()) / RAND_MAX * (UB-LB);
        printf("%.3lf\n", arr[i]);
    }
    
    mid_element = floor(n/2);
    cout << "Middle elements: ";
    printf("%.3lf\n", arr[mid_element]);
    
    delete[] arr;

return 0;
}

/*
    This code can be compiled and run ok.

    usage:
        NULL

    input file:
        NULL

    output files:
        NULL

    compile:
        g++ h44114025_hw1.cpp -o h44114025_hw1_out.cpp

    pseudocode:
    INSERTION_SORT(list, n)
    ------
    for i=1 to n do Begin
        key = list[i];
        j = i - 1;

        while j>=0 && list[j]>key do Begin
           list[j+1] = list[j];
            j--;
        End;

        list[j+1] = key;

    End;
    ------

    coded by 王晏國, ID: H44114025, email: h44114025@gs.ncku.edu.tw
    date: 2024.09.10
*/

#include <iostream>
using namespace std;

void insertionSort(int [], int);

int main()
{
    int n = 0;
    int min = 0;
    int min_2nd = 0;
    int max = 0;
    int max_2nd = 0;
    int sum = 0;
    int product = 1;

    cout << "Please input a positive integer n larger than 4: ";
    while (cin >> n){
        if (n <= 4){
            cout << "!!Warning!!" << n << "is NOT larger than 4!" << endl;
            cout << "Please input a positive integer n larger than 4: ";
            continue;
        }

        break;
    }

    int *data = new int(n);
    cout << "Please input " << n << " integers:";
    for (int i=0; i<n; i++){
        cin >> data[i];
    }

    cout << "Among the " << n << " integers: ";
    for (int i=0; i<n; i++){
        cout << data[i] << " ";
    }
    cout << endl;

    insertionSort(data, n);

    min = data[0];
    min_2nd = data[1];
    max = data[n-1];
    max_2nd = data[n-2];
    for (int i=0; i<n; i++){
        sum += data[i];
        product *= data[i];
    }

    cout << "min=" << min << "; ";
    cout << "2nd_min=" << min_2nd << "; ";
    cout << "max=" << max << "; ";
    cout << "2nd_max=" << max_2nd << "; ";
    cout << "sum=" << sum << "; ";
    cout << "product=" << product << "; ";

    return 0;
}

void insertionSort(int data[], int n){

    for (int i=1; i<n; i++){
        int key = data[i];
        int j = i - 1;

        while (j>=0 and data[j] > key){
            data[j+1] = data[j];
            j--;
        }
        data[j+1] = key;
    }

}
